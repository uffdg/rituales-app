
  # Create design system repository

  This is a code bundle for Create design system repository. The original project is available at https://www.figma.com/design/FE94Vtsm7rZVErgUktpH2K/Create-design-system-repository.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  