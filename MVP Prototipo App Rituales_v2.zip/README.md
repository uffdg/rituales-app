
  # MVP Prototipo App Rituales

  This is a code bundle for MVP Prototipo App Rituales. The original project is available at https://www.figma.com/design/qQj0jAJS6UwCVp6dxfv2ys/MVP-Prototipo-App-Rituales.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  